import React from "react";
import "./style.css";

function Footer() {
  return (
  <nav className="navbar fixed-bottom navbar-light bg-light" id="footer">
      <a className="navbar-brand" href="#">Fixed bottom</a>    
  </nav>
    // <footer className="footer">
    //   <span>Actor Search 2023</span>
    // </footer>
  );
}

export default Footer;
