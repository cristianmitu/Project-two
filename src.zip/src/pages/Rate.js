import React from "react"

function Rate() {
    return (
        <div>
            <h2>Rate</h2>
        </div>
    )
}

export default Rate;