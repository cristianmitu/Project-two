import React from "react";
import ActorSearch from "../components/ActorSearch";


function Results() {
  

  return (
    <div>
      <h2>{}Results</h2>
      <ActorSearch />
    </div>
  )
}

export default Results